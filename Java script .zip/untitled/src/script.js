// Optional: Add simple interactivity

document.addEventListener("DOMContentLoaded", () => {

  console.log("Portfolio loaded successfully!");

});